<form method=post action=c.php>
<input type=text name=get>
<input type=submit value=�Է�Ȯ��>
</form>